// Comparison table — sortable mini-table

function CompareTable() {
  const [sortKey, setSortKey] = React.useState(null);
  const [highlightCol, setHighlightCol] = React.useState(null);

  // Service support table
  const services = [
    { key: 'nin', label: '任意整理' },
    { key: 'sai', label: '個人再生' },
    { key: 'hasan', label: '自己破産' },
    { key: 'kabarai', label: '過払い金' },
  ];

  return (
    <>
      <SectionHeader
        id="compare"
        kicker="COMPARE"
        title="一目でわかる比較表"
        sub="気になる項目をタップしてハイライト"
      />

      <div style={{ padding: '8px 12px 4px' }}>
        <div style={{
          background: '#fff', borderRadius: 16,
          border: `1px solid ${COLORS.border}`,
          overflow: 'hidden',
          boxShadow: '0 6px 16px rgba(196, 110, 60, 0.06)',
        }}>
          {/* Header row */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '88px repeat(3, 1fr)',
            background: `linear-gradient(180deg, ${COLORS.primarySoft}, #FFF1E2)`,
            borderBottom: `1px solid ${COLORS.border}`,
          }}>
            <div style={{
              padding: '10px 8px',
              fontSize: 10, color: COLORS.inkSoft, fontWeight: 700,
              borderRight: `1px solid ${COLORS.border}`,
            }}>項目</div>
            {FIRMS.map((firm, i) => (
              <div key={firm.id}
                onClick={() => setHighlightCol(highlightCol === i ? null : i)}
                style={{
                  padding: '8px 4px', textAlign: 'center', cursor: 'pointer',
                  background: highlightCol === i ? '#fff' : 'transparent',
                  borderRight: i < 2 ? `1px solid ${COLORS.border}` : 'none',
                  transition: 'background 0.2s',
              }}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 4 }}>
                  <FirmEmblem firm={firm} size={28} radius={8} />
                </div>
                <div style={{
                  fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 800,
                  fontSize: 10, color: COLORS.ink, lineHeight: 1.2,
                }}>{firm.short}</div>
              </div>
            ))}
          </div>

          {/* Service rows (○/×) */}
          {services.map((s, ri) => (
            <div key={s.key} style={{
              display: 'grid',
              gridTemplateColumns: '88px repeat(3, 1fr)',
              borderBottom: `1px solid ${COLORS.border}`,
              background: ri % 2 === 0 ? '#fff' : '#FBF5EE',
            }}>
              <div style={{
                padding: '10px 10px', fontSize: 11, fontWeight: 700, color: COLORS.ink,
                borderRight: `1px solid ${COLORS.border}`,
                display: 'flex', alignItems: 'center',
              }}>{s.label}</div>
              {FIRMS.map((f, i) => (
                <div key={f.id} style={{
                  padding: '10px 4px', textAlign: 'center',
                  borderRight: i < 2 ? `1px solid ${COLORS.border}` : 'none',
                  background: highlightCol === i ? '#FFF8EE' : 'transparent',
                  display: 'flex', justifyContent: 'center', alignItems: 'center',
                }}>
                  {f.services[s.key]
                    ? <Icon.check size={20} color={COLORS.green} />
                    : <Icon.cross size={20} color="#D5C9BC" />}
                </div>
              ))}
            </div>
          ))}

          {/* Detail rows (text) */}
          {COMPARE_ROWS.slice(0, 6).map((row, ri) => (
            <div key={row.key} style={{
              display: 'grid',
              gridTemplateColumns: '88px repeat(3, 1fr)',
              borderBottom: ri < 5 ? `1px solid ${COLORS.border}` : 'none',
              background: ri % 2 === 0 ? '#fff' : '#FBF5EE',
            }}>
              <div style={{
                padding: '10px 10px', fontSize: 11, fontWeight: 700, color: COLORS.ink,
                borderRight: `1px solid ${COLORS.border}`,
                display: 'flex', alignItems: 'center',
              }}>{row.label}</div>
              {FIRMS.map((f, i) => (
                <div key={f.id} style={{
                  padding: '10px 6px', textAlign: 'center',
                  borderRight: i < 2 ? `1px solid ${COLORS.border}` : 'none',
                  background: highlightCol === i ? '#FFF8EE' : 'transparent',
                  fontSize: 11, fontWeight: 700, color: COLORS.ink,
                  lineHeight: 1.3,
                }}>
                  {row.accessor(f)}
                </div>
              ))}
            </div>
          ))}
        </div>

        <div style={{
          textAlign: 'center', fontSize: 10, color: COLORS.inkSoft,
          marginTop: 8,
        }}>
          ※税込表記。料金は2026年4月時点の参考目安です。
        </div>
      </div>
    </>
  );
}

Object.assign(window, { CompareTable });
