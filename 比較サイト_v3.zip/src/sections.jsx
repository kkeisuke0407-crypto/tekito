// Section components for the comparison site

const COLORS = {
  primary: '#FF6B35',
  primaryDark: '#E04E18',
  primarySoft: '#FFE3D1',
  cream: '#FFF8F0',
  warmWhite: '#FFFDF9',
  ink: '#2A1F1A',
  inkSoft: '#7A5A45',
  green: '#2FB67E',
  greenDark: '#1F8F5F',
  yellow: '#FFC247',
  border: '#F0E2D2',
  pink: '#FFE3EE',
};

// ─────────────────────────────────────────────────────────────
// Top app bar (sticky inside the phone)
// ─────────────────────────────────────────────────────────────
function AppBar() {
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 30,
      background: 'rgba(255, 253, 249, 0.92)',
      backdropFilter: 'blur(14px)',
      WebkitBackdropFilter: 'blur(14px)',
      borderBottom: `1px solid ${COLORS.border}`,
      padding: '8px 14px',
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <div style={{
          width: 30, height: 30, borderRadius: 9,
          background: `linear-gradient(135deg, ${COLORS.primary}, #FF9447)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900, fontSize: 17,
          boxShadow: '0 3px 8px rgba(255, 107, 53, 0.35)',
        }}>整</div>
        <div style={{ lineHeight: 1.05 }}>
          <div style={{
            fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900,
            fontSize: 15, color: COLORS.ink, letterSpacing: '-0.01em',
          }}>借金スッキリnavi</div>
          <div style={{ fontSize: 9, color: COLORS.inkSoft, letterSpacing: '0.06em' }}>
            DEBT RELIEF COMPARE 2026
          </div>
        </div>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ padding: 6, display: 'flex' }}><Icon.search size={20} /></div>
      <div style={{ padding: 6, display: 'flex' }}><Icon.menu size={22} /></div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Hero
// ─────────────────────────────────────────────────────────────
function Hero({ onJump }) {
  return (
    <section style={{
      position: 'relative', overflow: 'hidden',
      padding: '20px 18px 28px',
      background: `
        radial-gradient(160% 80% at 100% 0%, #FFCBA4 0%, transparent 55%),
        radial-gradient(120% 70% at 0% 100%, #FFD9C4 0%, transparent 60%),
        linear-gradient(180deg, #FFF6EC 0%, #FFEDDB 100%)
      `,
    }}>
      {/* floating decorative blob */}
      <div style={{
        position: 'absolute', top: -30, right: -30, width: 140, height: 140,
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(255,180,71,0.45), transparent 70%)',
        filter: 'blur(8px)',
      }} />

      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        background: '#fff', borderRadius: 999, padding: '5px 12px 5px 8px',
        fontSize: 11, fontWeight: 700, color: COLORS.primaryDark,
        boxShadow: '0 4px 10px rgba(255, 107, 53, 0.18)',
        position: 'relative', zIndex: 1,
      }}>
        <span style={{
          width: 18, height: 18, borderRadius: '50%', background: COLORS.primary,
          color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11,
        }}>★</span>
        2026年4月 最新版
      </div>

      <h1 style={{
        margin: '12px 0 6px',
        fontFamily: '"Zen Maru Gothic", "M PLUS Rounded 1c", sans-serif',
        fontWeight: 900,
        fontSize: 30,
        lineHeight: 1.2,
        letterSpacing: '-0.02em',
        color: COLORS.ink,
        position: 'relative', zIndex: 1,
        textWrap: 'balance',
      }}>
        借金の悩み、<br/>
        <span style={{
          background: `linear-gradient(180deg, transparent 60%, #FFD480 60%)`,
          padding: '0 4px',
        }}>3分で</span>
        スッキリ。
      </h1>

      <p style={{
        margin: '6px 0 18px',
        fontSize: 13, color: COLORS.inkSoft, lineHeight: 1.7,
        position: 'relative', zIndex: 1,
      }}>
        本当に頼れる債務整理の事務所を、<br/>
        現役FPと元相談員が<b style={{ color: COLORS.ink }}>9項目</b>で徹底比較。
      </p>

      {/* stat row */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8,
        marginBottom: 18, position: 'relative', zIndex: 1,
      }}>
        {[
          { n: '3', l: '厳選事務所' },
          { n: '無料', l: '相談料' },
          { n: '24h', l: '受付対応' },
        ].map((s, i) => (
          <div key={i} style={{
            background: '#fff', borderRadius: 14, padding: '10px 6px',
            textAlign: 'center',
            boxShadow: '0 4px 12px rgba(196, 110, 60, 0.08)',
          }}>
            <div style={{
              fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900,
              fontSize: 20, color: COLORS.primary, lineHeight: 1,
            }}>{s.n}</div>
            <div style={{ fontSize: 10, color: COLORS.inkSoft, marginTop: 4 }}>{s.l}</div>
          </div>
        ))}
      </div>

      <button onClick={() => onJump('ranking')} style={{
        width: '100%', border: 'none',
        background: `linear-gradient(180deg, #FF8A4D, ${COLORS.primary})`,
        color: '#fff',
        fontFamily: '"M PLUS Rounded 1c", sans-serif', fontWeight: 800,
        fontSize: 16, padding: '14px',
        borderRadius: 16,
        boxShadow: '0 8px 18px rgba(255, 107, 53, 0.4), inset 0 1px 0 rgba(255,255,255,0.3)',
        cursor: 'pointer',
        position: 'relative', zIndex: 1,
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      }}>
        おすすめ3選を見る
        <Icon.chevron size={16} color="#fff" dir="down" />
      </button>

      <div style={{
        marginTop: 10, fontSize: 11, color: COLORS.inkSoft, textAlign: 'center',
        position: 'relative', zIndex: 1,
      }}>
        ※相談無料・匿名OK・全国対応
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────
// Worry checklist (浮かぶ系のコピーセクション)
// ─────────────────────────────────────────────────────────────
function WorryStrip() {
  const items = [
    'リボ払いの残高が減らない…',
    '複数社から借入していて返済キツい',
    '家族にバレずに整理したい',
    '督促の電話が止まらない',
  ];
  return (
    <section style={{ padding: '22px 16px 8px', background: COLORS.warmWhite }}>
      <div style={{
        textAlign: 'center', marginBottom: 14,
        fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 800,
        fontSize: 18, color: COLORS.ink,
      }}>
        こんなお悩み、ありませんか？
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {items.map((t, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            background: COLORS.cream, borderRadius: 12,
            padding: '10px 14px',
            border: `1px solid ${COLORS.border}`,
            fontSize: 13, color: COLORS.ink, fontWeight: 500,
          }}>
            <span style={{
              width: 22, height: 22, borderRadius: '50%',
              background: '#FFE3D1', color: COLORS.primaryDark,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 13, fontWeight: 800, flexShrink: 0,
            }}>?</span>
            {t}
          </div>
        ))}
      </div>
      <div style={{
        textAlign: 'center', marginTop: 14, fontSize: 13, fontWeight: 700, color: COLORS.primaryDark,
      }}>
        ↓ ぜんぶ債務整理で解決できます ↓
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────
// Section header (with anchor id)
// ─────────────────────────────────────────────────────────────
function SectionHeader({ id, kicker, title, sub }) {
  return (
    <div id={id} style={{ padding: '24px 18px 8px', textAlign: 'center' }}>
      <div style={{
        display: 'inline-block',
        fontFamily: '"M PLUS Rounded 1c", sans-serif',
        fontSize: 11, fontWeight: 800, letterSpacing: '0.18em',
        color: COLORS.primary,
        background: COLORS.primarySoft,
        padding: '4px 12px', borderRadius: 999,
      }}>{kicker}</div>
      <h2 style={{
        margin: '10px 0 4px',
        fontFamily: '"Zen Maru Gothic", sans-serif',
        fontWeight: 900, fontSize: 22, color: COLORS.ink, lineHeight: 1.3,
        letterSpacing: '-0.01em',
      }}>{title}</h2>
      {sub && <p style={{ margin: 0, fontSize: 12, color: COLORS.inkSoft }}>{sub}</p>}
    </div>
  );
}

Object.assign(window, { COLORS, AppBar, Hero, WorryStrip, SectionHeader });
