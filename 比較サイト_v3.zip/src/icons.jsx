// SVG icons + small visual primitives
// All icons accept { size, color }

const Icon = {
  phone: ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M5 4c0-.55.45-1 1-1h3l2 5-2.5 1.5a11 11 0 005 5L15 12l5 2v3c0 .55-.45 1-1 1A15 15 0 015 4z" fill={color}/>
    </svg>
  ),
  line: ({ size = 18, color = '#fff', bg = '#06C755' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <rect width="24" height="24" rx="6" fill={bg}/>
      <path d="M12 5C7.58 5 4 7.83 4 11.32c0 3.13 2.85 5.75 6.71 6.25.26.06.61.17.7.39.08.2.05.51.03.71l-.11.69c-.04.21-.16.83.73.45.89-.38 4.79-2.82 6.53-4.83C19.74 13.66 20 12.55 20 11.32 20 7.83 16.42 5 12 5z" fill={color}/>
    </svg>
  ),
  star: ({ size = 14, color = '#FFA726', filled = true }) => (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
        fill={filled ? color : 'none'} stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
    </svg>
  ),
  check: ({ size = 16, color = '#2FB67E' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" fill={color} opacity="0.15"/>
      <path d="M7 12.5l3 3 7-7" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  cross: ({ size = 16, color = '#C7C2BC' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" fill={color} opacity="0.18"/>
      <path d="M8 8l8 8M16 8l-8 8" stroke={color} strokeWidth="2.2" strokeLinecap="round"/>
    </svg>
  ),
  chevron: ({ size = 14, color = 'currentColor', dir = 'down' }) => {
    const r = { down: 0, up: 180, left: 90, right: -90 }[dir] || 0;
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ transform: `rotate(${r}deg)`, transition: 'transform .2s' }}>
        <path d="M6 9l6 6 6-6" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    );
  },
  menu: ({ size = 22, color = '#2A1F1A' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M4 7h16M4 12h16M4 17h11" stroke={color} strokeWidth="2.2" strokeLinecap="round"/>
    </svg>
  ),
  search: ({ size = 18, color = '#7A5A45' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="11" r="6" stroke={color} strokeWidth="2"/>
      <path d="M20 20l-3.5-3.5" stroke={color} strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  yen: ({ size = 18, color = '#FF6B35' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M6 4l6 8 6-8M6 14h12M6 18h12M12 12v9" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  clock: ({ size = 18, color = '#FF6B35' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="2"/>
      <path d="M12 7v5l3 2" stroke={color} strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  shield: ({ size = 18, color = '#FF6B35' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z" stroke={color} strokeWidth="2" strokeLinejoin="round"/>
      <path d="M9 12l2 2 4-4" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  spark: ({ size = 16, color = '#FF6B35' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8" stroke={color} strokeWidth="2" strokeLinecap="round"/>
    </svg>
  ),
  sort: ({ size = 14, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M7 4v16M7 4l-3 3M7 4l3 3M17 20V4M17 20l-3-3M17 20l3-3" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
};

// 5-star rating display
function Stars({ value = 5, size = 13 }) {
  const full = Math.floor(value);
  const half = value - full >= 0.5;
  return (
    <span style={{ display: 'inline-flex', gap: 1 }}>
      {[0,1,2,3,4].map(i => {
        const filled = i < full;
        const isHalf = i === full && half;
        return (
          <span key={i} style={{ position: 'relative', display: 'inline-flex' }}>
            <Icon.star size={size} color="#FFC247" filled={filled || isHalf} />
            {isHalf && (
              <span style={{ position: 'absolute', inset: 0, width: '50%', overflow: 'hidden' }}>
                <Icon.star size={size} color="#E8E2DA" filled />
              </span>
            )}
          </span>
        );
      })}
    </span>
  );
}

// Big rounded emblem with the firm's initial — stands in for a logo
function FirmEmblem({ firm, size = 56, radius = 16 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: radius,
      background: firm.emblemBg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#fff',
      fontFamily: '"Zen Maru Gothic", "M PLUS Rounded 1c", sans-serif',
      fontWeight: 900,
      fontSize: size * 0.5,
      flexShrink: 0,
      boxShadow: `0 6px 14px ${firm.typeColor}33, inset 0 1px 0 rgba(255,255,255,0.25)`,
      letterSpacing: '-0.02em',
    }}>{firm.initial}</div>
  );
}

// Striped placeholder for any "image goes here" need
function Placeholder({ w = '100%', h = 120, label = 'image' }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: 12,
      background: 'repeating-linear-gradient(45deg, #F5E9DC 0 8px, #FBF2E6 8px 16px)',
      border: '1px dashed #D9C4A8',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#A07D5E', fontFamily: 'ui-monospace, monospace', fontSize: 11,
    }}>{label}</div>
  );
}

Object.assign(window, { Icon, Stars, FirmEmblem, Placeholder });
