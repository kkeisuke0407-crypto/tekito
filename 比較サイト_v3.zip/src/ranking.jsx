// Ranking cards section — 3 firms displayed equally as "おすすめ3選"

function RankBadge({ label, color }) {
  return (
    <div style={{
      position: 'absolute', top: -10, left: 14,
      background: color, color: '#fff',
      fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900,
      fontSize: 11, padding: '4px 10px', borderRadius: 999,
      letterSpacing: '0.04em',
      boxShadow: `0 4px 10px ${color}55`,
    }}>{label}</div>
  );
}

function FirmCard({ firm, pickLabel, pickColor }) {
  const [hover, setHover] = React.useState(false);

  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        background: '#fff',
        borderRadius: 20,
        padding: '18px 16px 16px',
        border: `1px solid ${COLORS.border}`,
        boxShadow: hover
          ? '0 14px 30px rgba(196, 110, 60, 0.18)'
          : '0 6px 16px rgba(196, 110, 60, 0.08)',
        transform: hover ? 'translateY(-3px)' : 'translateY(0)',
        transition: 'all 0.25s cubic-bezier(.2,.8,.2,1)',
        overflow: 'visible',
    }}>
      <RankBadge label={pickLabel} color={pickColor} />

      {/* Header row */}
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
        <FirmEmblem firm={firm} size={56} radius={16} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            display: 'inline-block',
            fontSize: 10, fontWeight: 700,
            color: firm.typeColor,
            background: firm.accent,
            padding: '2px 8px', borderRadius: 4,
            marginBottom: 4,
          }}>{firm.type}</div>
          <div style={{
            fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 800,
            fontSize: 15, lineHeight: 1.3, color: COLORS.ink,
            letterSpacing: '-0.01em',
          }}>{firm.name}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <Stars value={firm.rating} size={12} />
            <span style={{ fontSize: 12, fontWeight: 700, color: COLORS.ink }}>{firm.rating}</span>
            <span style={{ fontSize: 10, color: COLORS.inkSoft }}>
              ({firm.reviewCount.toLocaleString()})
            </span>
          </div>
        </div>
      </div>

      {/* Tagline */}
      <div style={{
        marginTop: 12, padding: '8px 12px',
        background: firm.bg, borderRadius: 10,
        fontSize: 12, fontWeight: 700, color: firm.typeColor,
        display: 'flex', alignItems: 'center', gap: 6,
      }}>
        <Icon.spark size={14} color={firm.typeColor} />
        {firm.tagline}
      </div>

      {/* Quick spec grid */}
      <div style={{
        marginTop: 12,
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6,
      }}>
        {[
          ['任意整理 / 1社', firm.fee.taskPerCase, '#FF6B35'],
          ['対応スピード', firm.speed, '#2FB67E'],
          ['対応エリア', firm.area.replace('（一部訴訟は不可）', ''), '#4A90E2'],
          ['実績', firm.record, '#A062D4'],
        ].map(([label, val, c], i) => (
          <div key={i} style={{
            background: '#FBF5EE', borderRadius: 10, padding: '8px 10px',
          }}>
            <div style={{ fontSize: 9, color: COLORS.inkSoft, fontWeight: 600, marginBottom: 2 }}>
              {label}
            </div>
            <div style={{
              fontFamily: '"M PLUS Rounded 1c", sans-serif', fontWeight: 800,
              fontSize: 13, color: c, lineHeight: 1.2,
            }}>{val}</div>
          </div>
        ))}
      </div>

      {/* Badges */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginTop: 10 }}>
        {firm.badges.map((b, i) => (
          <span key={i} style={{
            fontSize: 10, fontWeight: 700,
            color: COLORS.inkSoft, background: '#F5EBDC',
            padding: '3px 8px', borderRadius: 999,
            border: `1px solid ${COLORS.border}`,
          }}># {b}</span>
        ))}
      </div>

      {/* Pros/cons compact */}
      <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 5 }}>
        {firm.pros.slice(0, 2).map((p, i) => (
          <div key={i} style={{ display: 'flex', gap: 6, alignItems: 'flex-start', fontSize: 12, color: COLORS.ink, lineHeight: 1.5 }}>
            <Icon.check size={14} color={COLORS.green} />
            <span>{p}</span>
          </div>
        ))}
      </div>

      {/* CTA button */}
      <a
        href={firm.affiliateUrl}
        target="_blank"
        rel="nofollow noopener noreferrer"
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          marginTop: 14,
          border: 'none', cursor: 'pointer', textDecoration: 'none',
          background: `linear-gradient(180deg, #FF8A4D, ${COLORS.primary})`,
          color: '#fff', fontFamily: '"M PLUS Rounded 1c", sans-serif', fontWeight: 800,
          fontSize: 14, padding: '14px 8px',
          borderRadius: 14,
          boxShadow: '0 6px 16px rgba(255, 107, 53, 0.45)',
        }}
      >
        <Icon.phone size={15} color="#fff" />
        無料相談はこちら（公式サイト）
      </a>
      <div style={{ marginTop: 6, textAlign: 'center', fontSize: 10, color: COLORS.inkSoft }}>
        相談料0円・匿名OK・全国対応
      </div>

      {/* Pick-for footer */}
      <div style={{
        marginTop: 12, paddingTop: 10,
        borderTop: `1px dashed ${COLORS.border}`,
        fontSize: 11, color: COLORS.inkSoft,
        display: 'flex', alignItems: 'center', gap: 6,
      }}>
        <span style={{ fontWeight: 700, color: COLORS.primaryDark }}>こんな人に◎</span>
        {firm.pickFor}
      </div>
    </div>
  );
}

function RankingSection() {
  const picks = [
    { label: '安心NO.1', color: '#E8487A' },
    { label: '安さNO.1', color: '#2FB67E' },
    { label: '実績NO.1', color: '#FF6B35' },
  ];
  return (
    <>
      <SectionHeader
        id="ranking"
        kicker="OUR TOP 3"
        title="おすすめの債務整理 3選"
        sub="それぞれ得意分野が違うので、自分に合うところを選ぼう"
      />
      <div style={{ padding: '14px 16px 8px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {FIRMS.map((firm, i) => (
          <FirmCard key={firm.id} firm={firm} pickLabel={picks[i].label} pickColor={picks[i].color} />
        ))}
      </div>
    </>
  );
}

Object.assign(window, { RankingSection, FirmCard });
