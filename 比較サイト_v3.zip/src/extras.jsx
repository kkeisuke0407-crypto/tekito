// Reviews + FAQ + footer

function ReviewCard({ r }) {
  const firm = FIRMS.find(f => f.id === r.firmId);
  return (
    <div style={{
      background: '#fff', borderRadius: 16,
      padding: '14px 14px 12px',
      border: `1px solid ${COLORS.border}`,
      boxShadow: '0 6px 14px rgba(196, 110, 60, 0.06)',
      minWidth: 240, flexShrink: 0,
      scrollSnapAlign: 'start',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%',
          background: 'linear-gradient(135deg, #FFD7E2, #FFE3D1)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900,
          color: COLORS.primaryDark, fontSize: 14,
        }}>{r.name.charAt(0)}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.ink }}>{r.name}</div>
          <div style={{ fontSize: 10, color: COLORS.inkSoft }}>{r.age}</div>
        </div>
        <Stars value={r.rating} size={11} />
      </div>
      <p style={{
        margin: 0, fontSize: 12, lineHeight: 1.7, color: COLORS.ink,
        textWrap: 'pretty',
      }}>{r.text}</p>
      <div style={{
        marginTop: 10, paddingTop: 8,
        borderTop: `1px dashed ${COLORS.border}`,
        display: 'flex', alignItems: 'center', gap: 6,
        fontSize: 10, color: COLORS.inkSoft,
      }}>
        <FirmEmblem firm={firm} size={18} radius={5} />
        <span style={{ fontWeight: 700, color: firm.typeColor }}>{firm.short}</span>
        を利用
      </div>
    </div>
  );
}

function ReviewsSection() {
  return (
    <>
      <SectionHeader
        id="reviews"
        kicker="REAL VOICES"
        title="利用者のリアルな声"
        sub="←→ スワイプで他のレビューも見られます"
      />
      <div style={{
        display: 'flex', gap: 12, overflowX: 'auto',
        padding: '8px 16px 18px',
        scrollSnapType: 'x mandatory',
        WebkitOverflowScrolling: 'touch',
      }} className="ios-scroll">
        {REVIEWS.map((r, i) => <ReviewCard key={i} r={r} />)}
      </div>
    </>
  );
}

function FAQItem({ item, open, onToggle }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 14,
      border: `1px solid ${COLORS.border}`,
      overflow: 'hidden',
      transition: 'all 0.2s',
      boxShadow: open ? '0 8px 18px rgba(196, 110, 60, 0.1)' : 'none',
    }}>
      <button onClick={onToggle} style={{
        width: '100%', border: 'none', background: 'none', cursor: 'pointer',
        padding: '14px 14px', textAlign: 'left',
        display: 'flex', alignItems: 'flex-start', gap: 10,
      }}>
        <span style={{
          width: 22, height: 22, borderRadius: '50%',
          background: COLORS.primary, color: '#fff',
          fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900, fontSize: 13,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>Q</span>
        <span style={{ flex: 1, fontSize: 13, fontWeight: 700, color: COLORS.ink, lineHeight: 1.5 }}>
          {item.q}
        </span>
        <span style={{ paddingTop: 4 }}>
          <Icon.chevron size={14} color={COLORS.inkSoft} dir={open ? 'up' : 'down'} />
        </span>
      </button>
      <div style={{
        maxHeight: open ? 300 : 0,
        opacity: open ? 1 : 0,
        transition: 'max-height 0.3s ease, opacity 0.3s ease, padding 0.3s ease',
        padding: open ? '0 14px 14px 14px' : '0 14px',
      }}>
        <div style={{
          display: 'flex', gap: 10, alignItems: 'flex-start',
          paddingTop: 10, borderTop: `1px dashed ${COLORS.border}`,
        }}>
          <span style={{
            width: 22, height: 22, borderRadius: '50%',
            background: COLORS.green, color: '#fff',
            fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900, fontSize: 13,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>A</span>
          <p style={{ margin: 0, fontSize: 12, lineHeight: 1.7, color: COLORS.inkSoft, textWrap: 'pretty' }}>
            {item.a}
          </p>
        </div>
      </div>
    </div>
  );
}

function FAQSection() {
  const [openIdx, setOpenIdx] = React.useState(0);
  return (
    <>
      <SectionHeader
        id="faq"
        kicker="FAQ"
        title="よくある質問"
        sub="気になるところをタップ"
      />
      <div style={{ padding: '8px 16px 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {FAQS.map((item, i) => (
          <FAQItem key={i} item={item} open={openIdx === i} onToggle={() => setOpenIdx(openIdx === i ? -1 : i)} />
        ))}
      </div>
    </>
  );
}

// Final CTA banner
function FinalCTA() {
  return (
    <section style={{
      margin: '8px 16px 16px',
      padding: '20px 16px',
      borderRadius: 22,
      background: `
        radial-gradient(120% 100% at 100% 0%, #FFB07A 0%, transparent 60%),
        linear-gradient(135deg, #FF6B35 0%, #E04E18 100%)
      `,
      color: '#fff', position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', top: -20, right: -20, width: 100, height: 100,
        borderRadius: '50%', background: 'rgba(255,255,255,0.1)',
      }} />
      <div style={{
        fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900,
        fontSize: 11, color: '#FFD89C', letterSpacing: '0.1em', marginBottom: 4,
      }}>まずは無料相談から</div>
      <h3 style={{
        margin: 0, fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900,
        fontSize: 22, lineHeight: 1.3, letterSpacing: '-0.01em',
      }}>
        悩む時間がもったいない。<br/>
        今日が、人生で一番若い日。
      </h3>
      <p style={{
        margin: '8px 0 14px', fontSize: 12, lineHeight: 1.6, opacity: 0.92,
      }}>
        匿名OK・全国対応・24時間受付<br/>
        家族にバレずに整理できます
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {FIRMS.map(firm => (
          <a
            key={firm.id}
            href={firm.affiliateUrl}
            target="_blank"
            rel="nofollow noopener noreferrer"
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '12px 14px', borderRadius: 12, textDecoration: 'none',
              background: 'rgba(255,255,255,0.18)',
              border: '1px solid rgba(255,255,255,0.35)',
              backdropFilter: 'blur(4px)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: 8, flexShrink: 0,
                background: firm.emblemBg,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontFamily: '"Zen Maru Gothic", sans-serif',
                fontWeight: 900, fontSize: 13,
              }}>{firm.initial}</div>
              <span style={{ color: '#fff', fontWeight: 700, fontSize: 13 }}>{firm.short}</span>
            </div>
            <span style={{
              color: '#fff', fontFamily: '"M PLUS Rounded 1c", sans-serif',
              fontWeight: 800, fontSize: 12,
              background: 'rgba(255,255,255,0.25)', padding: '4px 10px', borderRadius: 999,
            }}>無料相談 →</span>
          </a>
        ))}
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer style={{
      padding: '20px 18px 30px',
      background: '#2A1F1A', color: '#A89A88',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <div style={{
          width: 26, height: 26, borderRadius: 8,
          background: COLORS.primary,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 900, fontSize: 14,
        }}>整</div>
        <div style={{
          fontFamily: '"Zen Maru Gothic", sans-serif', fontWeight: 800,
          fontSize: 14, color: '#fff',
        }}>借金スッキリnavi</div>
      </div>
      <p style={{ margin: '0 0 12px', fontSize: 10, lineHeight: 1.7 }}>
        本サイトは債務整理に関する情報をまとめた比較サイトです。<br/>
        掲載情報は各事務所の公式情報を元にダミーデータとして作成しています。
      </p>
      <div style={{
        display: 'flex', gap: 16, fontSize: 10, paddingTop: 10,
        borderTop: '1px solid #3D2F26',
      }}>
        <span>運営者情報</span>
        <span>プライバシー</span>
        <span>免責事項</span>
        <span>お問い合わせ</span>
      </div>
      <div style={{ marginTop: 12, fontSize: 9, opacity: 0.6 }}>
        © 2026 借金スッキリnavi (demo)
      </div>
    </footer>
  );
}

Object.assign(window, { ReviewsSection, FAQSection, FinalCTA, Footer });
