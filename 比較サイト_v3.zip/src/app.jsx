// Main app — assembles all sections inside the iOS device frame

function StickyCTA({ visible }) {
  return (
    <div style={{
      position: 'absolute',
      bottom: visible ? 34 : -80, left: 0, right: 0,
      transition: 'bottom 0.35s cubic-bezier(.2,.8,.2,1)',
      padding: '10px 12px',
      background: 'rgba(255, 253, 249, 0.92)',
      backdropFilter: 'blur(14px)',
      WebkitBackdropFilter: 'blur(14px)',
      borderTop: `1px solid ${COLORS.border}`,
      display: 'flex', gap: 8,
      zIndex: 40,
    }}>
      <button style={{
        flex: 1, border: 'none', cursor: 'pointer',
        background: `linear-gradient(180deg, #FF8A4D, ${COLORS.primary})`,
        color: '#fff', fontFamily: '"M PLUS Rounded 1c", sans-serif', fontWeight: 800,
        fontSize: 13, padding: '12px', borderRadius: 12,
        boxShadow: '0 6px 14px rgba(255, 107, 53, 0.4)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon.phone size={14} color="#fff" />
        無料電話相談
      </button>
      <button style={{
        flex: 1, border: 'none', cursor: 'pointer',
        background: '#06C755', color: '#fff',
        fontFamily: '"M PLUS Rounded 1c", sans-serif', fontWeight: 800,
        fontSize: 13, padding: '12px', borderRadius: 12,
        boxShadow: '0 6px 14px rgba(6, 199, 85, 0.35)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon.line size={14} color="#fff" bg="transparent" />
        LINEで相談
      </button>
    </div>
  );
}

function App() {
  const scrollRef = React.useRef(null);
  const [showCTA, setShowCTA] = React.useState(false);

  // Show sticky CTA after user scrolls past hero
  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => setShowCTA(el.scrollTop > 320);
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => el.removeEventListener('scroll', onScroll);
  }, []);

  const jumpTo = (id) => {
    const el = document.getElementById(id);
    if (!el || !scrollRef.current) return;
    const top = el.offsetTop - 50;
    scrollRef.current.scrollTo({ top, behavior: 'smooth' });
  };

  return (
    <div style={{ position: 'relative', height: '100%' }}>
      <div ref={scrollRef} className="ios-scroll" style={{
        height: '100%', overflowY: 'auto', overflowX: 'hidden',
        background: COLORS.warmWhite,
        paddingTop: 50, /* space for status bar */
      }}>
        <AppBar />
        <Hero onJump={jumpTo} />
        <WorryStrip />
        <RankingSection />
        <CompareTable />
        <ReviewsSection />
        <FAQSection />
        <FinalCTA />
        <Footer />
        <div style={{ height: 80 }} />
      </div>
      <StickyCTA visible={showCTA} />
    </div>
  );
}

function Page() {
  return (
    <div className="stage-inner">
      <div className="stage-meta">
        <b>借金スッキリnavi</b> — 債務整理おすすめ3選 比較サイト（モバイル）
      </div>
      <IOSDevice width={390} height={780} dark={false}>
        <App />
      </IOSDevice>
      <div className="stage-meta" style={{ maxWidth: 390 }}>
        ※ 掲載内容はダミーデータです。実在の事務所の料金・実績などは反映していません。
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Page />);
