# 弁護士の中の人 公式サイト 構築指示書（Claude Code用）

このドキュメントは、既存の探偵比較LP（vpscomparehub.com/detective/）を
**SNS流入専用のInstagram連動サイト「弁護士の中の人 公式サイト」**に
作り変えるための指示書です。

---

## 概要

**変更前**: 汎用SEO型探偵比較LP（浮気の証拠ナビ）
**変更後**: Instagram「@lawyer.nakanohito」公式サイト・SNS流入専用

---

## ファイル変更一覧

| ファイル | 変更内容 |
|---|---|
| `index.astro` | **完全置き換え** |
| `styles.css` | **追記のみ**（既存スタイルは残す） |
| `app.js` | **変更なし** |

---

## 作業手順

### Step 1: バックアップ
```bash
cp src/pages/detective/index.astro src/pages/detective/index.astro.bak
cp public/detective/styles.css public/detective/styles.css.bak
```

### Step 2: index.astro を完全置き換え
添付の `index.astro` ファイルで既存ファイルを上書き。

### Step 3: styles.css に追記
既存のstyles.cssは**消さずに残し**、添付の `styles_additions.css` の内容を
末尾に追記してください。

### Step 4: 確認
- ヒーロー右側の「もっと早く動いていれば」引用カードが表示される
- 「Instagramからお越しの方へ」セクションが表示される
- 「動く前の7つのチェック」セクションが表示される
- ヘッダー右上のInstagramリンクが表示される

---

## 重要な変更ポイント

### 1. 削除されたセクション
SEO目的で不要になったため、以下を削除：
- FAQ JSON-LD構造化データ
- 「探偵を選ぶ前に見るべき5つのポイント」セクション
- クイズマッチングセクション
- 「こんな方は探偵に相談する価値があります」セクション
- 料金プラン3種比較
- 「ご利用の流れ」5ステップ
- 「掲載基準・広告表記」の長文
- FAQ 7問 → 4問に削減

### 2. 新規追加されたセクション
- **Insta Welcome Section**: Instagram流入者向け歓迎メッセージ
- **Hero Quote Card**: 「もっと早く動いていれば」の引用カード
- **Checklist Section**: 動く前の7つのチェック + 結果に応じたCTA
- **Header Instagram Link**: ヘッダー右上にInstagramへの導線

### 3. コピー全体の変更
- サイト名: 浮気の証拠ナビ → **弁護士の中の人**
- ヒーローH1: 「浮気の証拠、自分で集める前に〜」→ 「気づいた今、何から動くかで結果が変わります」
- 全体トーン: SEO型 → 弁護士事務所スタッフ目線・インスタ連動

---

## アフィリンクの設定

`app.js` 内の `AFFILIATE_LINKS` オブジェクトを実際のリンクに更新してください：

```javascript
const AFFILIATE_LINKS = {
  gal:          "https://example.com/gal-agency",          // 総合探偵社ガルエージェンシー
  haraichi:     "https://example.com/haraichi",            // 原一探偵事務所
  hal:          "https://example.com/hal-detective",       // HAL探偵社
  matching:     "https://example.com/detective-matching",  // 探偵マッチングサービス
};
```

---

## CSS追加分の説明

`styles_additions.css` には以下のセクション用スタイルが含まれます：

1. **`.dt-header-insta`** - ヘッダーのInstagramリンクボタン
2. **`.hero-quote-card`** - ヒーロー右側の引用カード
3. **`.insta-welcome-*`** - Instagram歓迎セクション
4. **`.checklist-*`** - 7つのチェックリスト
5. **`@media (max-width: 768px)`** - 上記要素のレスポンシブ対応

---

## 公開後の確認事項

1. **Instagram→サイトの動線テスト**
   - インスタプロフのリンクからアクセス
   - ヒーロー〜歓迎セクションが正しく表示されるか

2. **チェックリスト→ランキングへのスクロール**
   - 「信頼できる探偵の選び方を見る」ボタンが正しく機能するか

3. **アフィリンクのトラッキング**
   - GA4で `detective_affiliate_click` イベントが発火するか

4. **モバイル表示**
   - iPhoneサイズで全セクションが崩れないか
   - ヘッダーInstagramリンクが正しく縮小されるか

---

## 今後の拡張可能性

このサイトは現在シングルページ構成ですが、以下の追加ページを作成可能：

- `/articles/` - インスタの内容を記事化（共感層向け）
- `/lawyer/` - 弁護士アフィ用ページ（探偵で不発の人を流す）
- `/quiz/` - 詳細診断ページ
- `/operator/` - 運営者情報
- `/privacy/` - プライバシーポリシー

---

## 関連リンク

- Instagram: https://www.instagram.com/lawyer.nakanohito/
- 旧サイト（参考）: https://vpscomparehub.com/detective/

---

最終更新: 2026年5月
